# AirDrop — Environmental Intelligence • Personal Safety • Connected Technology

**Detect. Alert. Stay Safe.**

[![App Live](https://img.shields.io/badge/App-Live-brightgreen)](https://foresight-alert-sphere.lovable.app/)
[![License](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Hardware](https://img.shields.io/badge/Hardware-ESP32-orange)]()
[![Firmware](https://img.shields.io/badge/Firmware-Arduino%20%2F%20PlatformIO-blue)]()

<p align="center">
  <img src="images/banner.png" alt="AirDrop Banner" width="100%">
</p>

---

## What is AirDrop?

**AirDrop** is a connected environmental safety ecosystem with three integrated parts:

| Component | Role |
|-----------|------|
| **AirDrop Pod** | Multi-sensor environmental monitoring unit (temperature, humidity, pressure, gas resistance, vibration, proximity) |
| **AirDrop Wearable** | Smartwatch-style companion that receives live data + alerts via BLE and provides SOS |
| **AirDrop Application** | Cloud-synced dashboard for live readings, risk history, maps and emergency contacts |

**The core idea:**

> The **Pod** monitors the environment.  
> The **Wearable** keeps the person informed.  
> The **App** connects everything.

**Live App:** [https://foresight-alert-sphere.lovable.app/](https://foresight-alert-sphere.lovable.app/)

---

## Why I Made It

Traditional environmental monitors are either stationary boxes that force you to check a screen, or expensive commercial systems with little personal feedback.

AirDrop closes that gap — real-time environmental awareness **on your wrist**, while still collecting rich multi-sensor data for analysis and emergency response. It targets schools, homes, industrial spaces and personal safety scenarios where early warning of unusual environmental changes can matter.

---

## How to Use It

### 1. Pod Setup
1. Power the AirDrop Pod (USB-C or battery).
2. Pod boots, calibrates sensors, and starts ESP-NOW (internal) + BLE + Wi-Fi.
3. Place it in the area you want to monitor (classroom, workspace, home, etc.).

### 2. Wearable Pairing
1. Power on the AirDrop Wearable.
2. It connects to the nearest Pod over **Bluetooth Low Energy**.
3. OLED shows live risk status, key readings and connection state.
4. On alert → vibration + visual warning. Press **SOS** for an emergency request.

### 3. Mobile Application
1. Open: [https://foresight-alert-sphere.lovable.app/](https://foresight-alert-sphere.lovable.app/)
2. View live dashboard, risk history and manage emergency contacts.
3. Firebase Realtime Database keeps everything synchronized.

**Offline capability:** Pod ↔ Wearable BLE continues to work and provide local alerts even without internet.

---

## System Architecture

<p align="center">
  <img src="diagrams/architecture_full.png" alt="System Architecture" width="100%">
</p>

```
┌─────────────────────── AIRDROP POD ───────────────────────┐
│  BME680 + MPU6050 + 2× HC-SR04                            │
│  ESP32 Node B  ──ESP-NOW──►  ESP32 Node A                 │
│         │                         │                       │
│         │                    Local Risk Engine            │
└─────────┼─────────────────────────┼───────────────────────┘
          │ BLE                     │ Wi-Fi
          ▼                         ▼
┌─────────────────┐         ┌─────────────────┐
│ AirDrop Wearable│         │   Firebase      │
│ OLED + Vibration│         │   Cloud         │
│ SOS Button      │         └────────┬────────┘
└─────────────────┘                  │
                                     ▼
                          ┌─────────────────────┐
                          │  AirDrop Mobile App │
                          └─────────────────────┘
```

| Technology | Purpose |
|------------|---------|
| **ESP-NOW** | Fast link between the two ESP32 nodes inside the Pod |
| **BLE** | Pod → Wearable live data & alerts |
| **Wi-Fi** | Pod → Firebase cloud sync |
| **Firebase** | Storage, history, multi-device sync |

---

## Hardware

### AirDrop Pod

| Component | Function |
|-----------|----------|
| ESP32 Node A | Main controller, risk engine, BLE + Wi-Fi |
| ESP32 Node B | Secondary sensing node |
| BME680 | Temperature, humidity, pressure, gas resistance |
| MPU6050 | Acceleration, vibration, orientation |
| 2 × HC-SR04 | Ultrasonic distance / proximity |
| ESP-NOW | Inter-node communication |
| Wi-Fi | Cloud uplink |

<p align="center">
  <img src="diagrams/pod_wiring.png" alt="Pod Wiring Diagram" width="90%">
</p>

### AirDrop Wearable

| Component | Function |
|-----------|----------|
| ESP32-C3 | Wearable controller (BLE + low power) |
| 0.96" SSD1306 OLED | Status, readings, alerts |
| Vibration motor + driver | Silent physical alerts |
| Buzzer | Audible alerts |
| SOS button | Emergency request |
| Protected Li-ion / LiPo | Portable power |

<p align="center">
  <img src="diagrams/wearable_wiring.png" alt="Wearable Wiring Diagram" width="80%">
</p>

---

## Risk Assessment Engine

The Pod runs a local multi-sensor risk engine that:

1. Validates readings (rejects outliers)
2. Performs basic sensor fusion
3. Detects sudden changes / trends
4. Outputs a preliminary risk score

<p align="center">
  <img src="diagrams/risk_flow.png" alt="Risk Assessment Flow" width="90%">
</p>

| Band | Score | Meaning |
|------|-------|---------|
| **Safe** | 0–25 | Normal conditions |
| **Caution** | 26–50 | Notable change |
| **Warning** | 51–75 | Significant anomaly |
| **Critical** | 76–100 | Strong multi-sensor indication |

> **Engineering note:** These are prototype classification bands, not scientifically validated safety thresholds. BME680 gas resistance is **not** a direct measurement of every toxic gas. The system must be calibrated and tested before any real-world safety claims.

---

## Visuals & Poster

<p align="center">
  <img src="images/AirDrop_Poster.png" alt="AirDrop Poster" width="70%">
</p>

Additional diagrams and renders are in:
- `images/` — poster, banner
- `diagrams/` — architecture, wiring, risk flow
- `3d/renders/` — place your final 3D renders here

---

## Repository Structure

```
AirDrop/
├── README.md                          ← You are here
├── LICENSE
├── bom/
│   └── AirDrop_BOM.csv                ← Bill of Materials with links
├── docs/
│   ├── project-explanation.md
│   ├── one-minute-pitch.md
│   └── limitations.md
├── diagrams/
│   ├── architecture_full.png / .svg
│   ├── pod_wiring.png / .svg
│   ├── wearable_wiring.png / .svg
│   └── risk_flow.png / .svg
├── images/
│   ├── AirDrop_Poster.png
│   └── banner.png
├── firmware/
│   ├── pod_nodeA/                     ← Main Pod firmware (ESP32)
│   ├── pod_nodeB/                     ← Sensor node firmware
│   └── wearable/                      ← Wearable firmware (ESP32-C3)
├── pcb/
│   ├── pod/                           ← KiCad project (Pod)
│   │   ├── AirDrop_Pod.kicad_pro
│   │   ├── AirDrop_Pod.kicad_sch
│   │   ├── AirDrop_Pod.kicad_pcb
│   │   ├── AirDrop_Pod.kicad_prl
│   │   └── gerbers.zip (export when ready)
│   └── wearable/                      ← KiCad project (Wearable)
├── 3d/
│   ├── pod/
│   │   ├── AirDrop_Pod_Enclosure.scad ← Parametric source
│   │   ├── AirDrop_Pod_Bottom.step    ← STEP
│   │   └── *.stl
│   ├── wearable/
│   │   ├── AirDrop_Wearable_Case.scad
│   │   └── *.stl
│   ├── assembly/
│   │   └── AirDrop_Full_Assembly.scad
│   └── MECHANICAL_DESIGN_SPEC.md
└── app/
    └── README.md                      ← Live app notes
```

---

## CAD / 3D Models

| File | Description |
|------|-------------|
| `3d/pod/AirDrop_Pod_Enclosure.scad` | Full Pod enclosure (parametric OpenSCAD) |
| `3d/pod/AirDrop_Pod_Bottom.step` | Pod bottom STEP (AP214) |
| `3d/pod/*.stl` | Printable meshes |
| `3d/wearable/AirDrop_Wearable_Case.scad` | Wearable case source |
| `3d/wearable/*.stl` | Wearable meshes |
| `3d/assembly/AirDrop_Full_Assembly.scad` | Full system assembly |
| `3d/MECHANICAL_DESIGN_SPEC.md` | Dimensions & design rules |

**Export more STEP files:** Open any `.scad` in [OpenSCAD](https://openscad.org) or FreeCAD → Render (F6) → File → Export → STEP.

---

## PCB Source Files (KiCad)

Both boards include the required checklist files:

- `.kicad_pro`
- `.kicad_sch`
- `.kicad_pcb`
- `.kicad_prl`

Locations:
- `pcb/pod/`
- `pcb/wearable/`

Export Gerbers from KiCad and place as `gerbers.zip` in each folder when ready for fabrication.

---

## Firmware

| Target | Path | MCU |
|--------|------|-----|
| Pod Node A (main) | `firmware/pod_nodeA/` | ESP32 |
| Pod Node B (sensors) | `firmware/pod_nodeB/` | ESP32 |
| Wearable | `firmware/wearable/` | ESP32-C3 |

Each folder contains:
- `platformio.ini`
- `src/main.cpp` (complete structural firmware with ESP-NOW, BLE, risk engine outline, OLED/haptics/SOS)

**Design submission note:** Firmware is provided as a complete architectural implementation. Untested status on final hardware is acceptable for design submissions.

Build with PlatformIO:
```bash
cd firmware/pod_nodeA
pio run
```

---

## Bill of Materials

See **[`bom/AirDrop_BOM.csv`](bom/AirDrop_BOM.csv)** for the full list with purchase links.

Key items include dual ESP32 modules, BME680, MPU6050, HC-SR04 ×2, ESP32-C3, SSD1306 OLED, vibration motor, SOS button, and protected LiPo.

---

## Live Application

**URL:** [https://foresight-alert-sphere.lovable.app/](https://foresight-alert-sphere.lovable.app/)

Features:
- Live sensor dashboard
- Risk indicator
- Historical data
- Emergency / rescue mode interface

---

## Development Roadmap

| Stage | Focus |
|-------|-------|
| 1 | Complete Pod electronics & PCB |
| 2 | Sensor integration & calibration |
| 3 | ESP-NOW between nodes |
| 4 | Local risk assessment |
| 5 | Wearable hardware & enclosure |
| 6 | BLE + vibration alerts |
| 7 | Firebase connection |
| 8 | Mobile / web dashboard polish |
| 9 | SOS & offline behaviour |
| 10 | Full system validation |

---

## Honest Limitations

- BME680 gas resistance ≠ identification of every toxic gas
- MPU6050 does not independently detect earthquakes
- HC-SR04 is proximity only — not airflow or gas detection
- Current sensor set does not directly detect wildfires
- Risk score bands are prototype rules, not certified thresholds
- SOS delivery depends on connectivity
- Location features require a phone or additional GPS hardware

These are clear engineering boundaries and future development opportunities. See [`docs/limitations.md`](docs/limitations.md).

---

## One-Minute Pitch

> AirDrop is a connected environmental safety ecosystem that combines a multi-sensor monitoring Pod, a smartwatch-style wearable, and a cloud-synced mobile application.  
> The Pod uses dual ESP32 nodes with BME680, MPU6050 and ultrasonic sensors to collect and locally process environmental data, producing a preliminary risk score.  
> The Wearable receives this information over Bluetooth Low Energy and delivers vibration alerts and SOS capability directly on the user’s wrist.  
> Wi-Fi and Firebase keep the system synchronized with a modern web dashboard.  
> The vision is an accessible environmental safety network that helps people detect changes early and stay safer.

**AirDrop: Detect. Alert. Stay Safe.**

Full pitch: [`docs/one-minute-pitch.md`](docs/one-minute-pitch.md)  
Full explanation: [`docs/project-explanation.md`](docs/project-explanation.md)

---

## License

MIT License — see [`LICENSE`](LICENSE).

---

## Checklist Coverage (Design Submission)

| Requirement | Status |
|-------------|--------|
| What the project is & how to use it | ✅ This README |
| Why you made it | ✅ |
| Screenshots / diagrams (assembly, PCB, schematic, render) | ✅ `diagrams/` + `images/` + `3d/` |
| STEP files | ✅ `3d/pod/*.step` + export path from `.scad` |
| Source assembly file | ✅ `.scad` parametric sources + assembly |
| PCB source (KiCad: pro/sch/pcb/prl) | ✅ `pcb/pod/` & `pcb/wearable/` |
| Firmware | ✅ Complete C++ + PlatformIO |
| BOM as CSV with links | ✅ `bom/AirDrop_BOM.csv` |
| Poster / banner / extra graphics | ✅ `images/` |