# AirDrop Mechanical / CAD Design Specification

This document is the authoritative design brief for creating the 3D models, STEP files and assembly.

## 1. AirDrop Pod Enclosure

### Overall dimensions (target)
- Length: 110–130 mm
- Width: 70–85 mm
- Height: 35–45 mm
- Wall thickness: 2.0–2.5 mm
- Material suggestion: PETG or ABS (better heat resistance than PLA)

### Features required
- Two internal compartments or clear mounting bosses for:
  - ESP32 Node A board
  - ESP32 Node B board (or single board if consolidated later)
- Dedicated sensor bay with airflow for BME680 (do not seal the gas sensor)
- Openings / slots for HC-SR04 transducers (front or side)
- USB-C power port cutout
- Status LED light pipe or window
- 4× M3 mounting bosses for PCB
- Snap-fit or screw-closed lid
- Optional wall-mount keyhole or magnet recess on back

### Sensor placement rules
- BME680 must have air exchange with ambient (vents + small chamber)
- MPU6050 can be rigid-mounted to the PCB
- HC-SR04 faces outward with clear acoustic path
- Keep BME680 away from ESP32 heat sources if possible

### Export requirements
- Individual parts as `.step` (bottom, top, any internal brackets)
- Full assembly as `.step` or native source (`.f3d` / `.FCStd` / Onshape)

---

## 2. AirDrop Wearable Case

### Overall dimensions (target)
- Watch-like footprint: 40–48 mm diameter or 42×42 mm square rounded
- Thickness: 12–16 mm (including OLED and battery)
- Comfortable for continuous wear

### Features required
- Window / aperture for 0.96" SSD1306 OLED
- Side or top SOS button with positive tactile feel
- Internal cavity for ESP32-C3 SuperMini (or equivalent)
- Coin vibration motor pocket
- Battery compartment (protected LiPo)
- Strap lugs or integrated 20–22 mm spring-bar interface
- Minimal seams, smooth edges

### Design priorities
1. Comfort and wearability
2. Button accessibility under stress
3. OLED readability
4. Battery access / charging path

### Export requirements
- Case body, back cover, any internal frame as separate `.step`
- Full wearable assembly
- Optional strap interface model

---

## 3. Assembly Source File

Provide one of:
- Fusion 360 `.f3d` containing both Pod and Wearable assemblies with simplified electronics
- FreeCAD `.FCStd`
- Public Onshape document link (preferred for sharing)

Electronics can be represented as simplified blocks (PCB rectangle + major component footprints) so the assembly “includes electronics” as required by the checklist.

---

## 4. Visual Renders to Produce

From the CAD models generate and place in `images/` and `3d/renders/`:

1. Full system 3D assembly (Pod + Wearable side by side or in context)
2. Pod closed + exploded view
3. Wearable closed + exploded view
4. PCB-in-enclosure view for both devices
5. Clean hero render for the poster / README header

---

## 5. Recommended CAD Workflow

1. Model Pod enclosure from the dimensions above
2. Model Wearable from the dimensions above
3. Import or create simplified PCB / component blocks
4. Create assembly and explode configurations
5. Export all individual parts as STEP
6. Export full assembly STEP + keep native source
7. Produce renders (Fusion / FreeCAD / Blender / KeyShot)

This specification removes ambiguity so the CAD work is fully defined.