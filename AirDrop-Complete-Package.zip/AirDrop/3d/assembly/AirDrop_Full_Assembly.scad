// AirDrop Full Assembly Reference
// Open in OpenSCAD / FreeCAD → Export STEP of whole assembly

use <../pod/AirDrop_Pod_Enclosure.scad>
use <../wearable/AirDrop_Wearable_Case.scad>

// Pod at origin
pod_bottom();
translate([0, 0, 34]) color("steelblue", 0.6) pod_lid();

// Wearable placed to the right for visual assembly view
translate([160, 39, 0]) {
    wearable_body();
    translate([0, 0, -4]) color("gray", 0.7) wearable_back();
}

// Label
translate([60, -20, 0])
    color("white")
        linear_extrude(1)
            text("AirDrop System Assembly", size=8);
