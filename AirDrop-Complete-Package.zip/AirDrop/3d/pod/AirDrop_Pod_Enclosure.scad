// ============================================================
// AirDrop Pod Enclosure — Parametric OpenSCAD Model
// Opens in OpenSCAD or FreeCAD. Export → STEP / STL
// ============================================================

$fn = 64;

// ---- Overall dimensions (mm) ----
length      = 120;
width       = 78;
height      = 40;
wall        = 2.2;
lid_h       = 8;
tolerance   = 0.25;

// PCB mount
pcb_l = 70;
pcb_w = 50;
boss_h = 6;
boss_d = 6;
screw_d = 2.8;   // M3 clearance-ish

// Sensor / port cutouts
usb_w = 10;
usb_h = 4;
led_d = 3;
hc_d  = 16;      // HC-SR04 transducer diameter approx
vent_w = 2;
vent_l = 12;

module rounded_box(l, w, h, r) {
    hull() {
        translate([ r,  r, 0]) cylinder(h=h, r=r);
        translate([l-r,  r, 0]) cylinder(h=h, r=r);
        translate([ r, w-r, 0]) cylinder(h=h, r=r);
        translate([l-r, w-r, 0]) cylinder(h=h, r=r);
    }
}

module pod_bottom() {
    difference() {
        // Outer shell
        rounded_box(length, width, height - lid_h, 4);

        // Inner cavity
        translate([wall, wall, wall])
            rounded_box(length - 2*wall, width - 2*wall, height - lid_h, 2.5);

        // USB-C cutout (rear)
        translate([length/2 - usb_w/2, -1, 8])
            cube([usb_w, wall+2, usb_h]);

        // Status LED window (front)
        translate([length/2, width + 0.1, height - lid_h - 10])
            rotate([90, 0, 0])
                cylinder(h=wall+2, d=led_d);

        // HC-SR04 left transducer
        translate([25, width + 0.1, 18])
            rotate([90, 0, 0])
                cylinder(h=wall+2, d=hc_d);

        // HC-SR04 right transducer
        translate([50, width + 0.1, 18])
            rotate([90, 0, 0])
                cylinder(h=wall+2, d=hc_d);

        // Air vents for BME680 (side)
        for (i = [0:4]) {
            translate([-0.5, 15 + i*8, 12])
                cube([wall+1, vent_w, vent_l]);
        }
    }

    // PCB mounting bosses
    for (x = [wall + 8, wall + 8 + pcb_l]) {
        for (y = [wall + 8, wall + 8 + pcb_w]) {
            translate([x, y, wall])
                difference() {
                    cylinder(h=boss_h, d=boss_d);
                    translate([0, 0, 1])
                        cylinder(h=boss_h, d=screw_d);
                }
        }
    }

    // Lid alignment posts
    for (x = [8, length-8]) {
        for (y = [8, width-8]) {
            translate([x, y, height - lid_h - 3])
                cylinder(h=5, d=3);
        }
    }
}

module pod_lid() {
    difference() {
        rounded_box(length, width, lid_h, 4);

        // Inner recess for snap
        translate([wall/2, wall/2, -0.1])
            rounded_box(length - wall, width - wall, lid_h - wall + 0.2, 3);

        // Alignment holes
        for (x = [8, length-8]) {
            for (y = [8, width-8]) {
                translate([x, y, -0.1])
                    cylinder(h=lid_h + 0.2, d=3.3);
            }
        }

        // Logo / label recess
        translate([length/2 - 25, width/2 - 8, lid_h - 0.6])
            cube([50, 16, 1]);
    }
}

// ---- Assembly preview ----
pod_bottom();
translate([0, 0, height - lid_h + 2])
    color("steelblue", 0.7) pod_lid();

// ---- For export: uncomment one part at a time ----
// pod_bottom();
// pod_lid();