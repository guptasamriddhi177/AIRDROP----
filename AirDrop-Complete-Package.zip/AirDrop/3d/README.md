# AirDrop 3D / CAD Package

## Files Included

### Parametric Source (primary CAD)
| File | Description |
|------|-------------|
| `pod/AirDrop_Pod_Enclosure.scad` | Full Pod enclosure (bottom + lid) – parametric OpenSCAD |
| `wearable/AirDrop_Wearable_Case.scad` | Wearable body + back – parametric OpenSCAD |
| `assembly/AirDrop_Full_Assembly.scad` | Combined system assembly |

### STEP
| File | Description |
|------|-------------|
| `pod/AirDrop_Pod_Bottom.step` | Pod bottom solid (AP214) |

### STL (printable / preview meshes)
| File | Description |
|------|-------------|
| `pod/AirDrop_Pod_Bottom.stl` | Pod bottom |
| `pod/AirDrop_Pod_Lid.stl` | Pod lid |
| `wearable/AirDrop_Wearable_Body.stl` | Wearable main body |
| `wearable/AirDrop_Wearable_Back.stl` | Wearable back cover |

### Design Spec
See `MECHANICAL_DESIGN_SPEC.md` for exact dimensions, features and placement rules.

## How to export more STEP files
1. Install [OpenSCAD](https://openscad.org) or FreeCAD (free)
2. Open any `.scad` file
3. Uncomment the single-part module you want at the bottom of the file
4. Press F6 (Render)
5. File → Export → STEP (.step)

This produces clean, manifold STEP geometry suitable for the checklist.
