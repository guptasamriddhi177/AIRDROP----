// ============================================================
// AirDrop Wearable Case — Parametric OpenSCAD Model
// Wrist-worn form factor. Export → STEP / STL from OpenSCAD
// ============================================================

$fn = 80;

// Outer dimensions (mm)
outer_d   = 44;      // diameter
outer_h   = 14;      // total height
wall      = 1.6;
oled_w    = 27;      // 0.96" OLED approx viewing area
oled_h    = 15;
btn_d     = 6;       // SOS button
strap_w   = 20;      // spring bar width
strap_d   = 2.2;

module rounded_cyl(d, h, r) {
    hull() {
        translate([0, 0, r]) torus(d/2 - r, r);
        translate([0, 0, h - r]) torus(d/2 - r, r);
    }
}

module torus(R, r) {
    rotate_extrude()
        translate([R, 0, 0])
            circle(r=r);
}

module wearable_body() {
    difference() {
        // Main body
        cylinder(h=outer_h, d=outer_d);

        // Inner cavity
        translate([0, 0, wall])
            cylinder(h=outer_h - wall + 0.1, d=outer_d - 2*wall);

        // OLED window (front face)
        translate([-oled_w/2, -oled_h/2, outer_h - wall - 0.1])
            cube([oled_w, oled_h, wall + 0.2]);

        // SOS button hole (side)
        translate([outer_d/2 - 1, 0, outer_h/2])
            rotate([0, 90, 0])
                cylinder(h=wall + 2, d=btn_d);

        // Strap spring-bar holes
        for (side = [-1, 1]) {
            translate([0, side * (outer_d/2 - 1.5), outer_h/2])
                rotate([90, 0, 0])
                    cylinder(h=4, d=strap_d, center=true);
        }
    }

    // Internal OLED shelf
    translate([-oled_w/2 - 1, -oled_h/2 - 1, outer_h - wall - 3])
        difference() {
            cube([oled_w + 2, oled_h + 2, 2.5]);
            translate([1, 1, 0.5])
                cube([oled_w, oled_h, 2.2]);
        }

    // PCB bosses (3)
    for (a = [0, 120, 240]) {
        rotate([0, 0, a])
            translate([12, 0, wall])
                difference() {
                    cylinder(h=4, d=4.5);
                    translate([0, 0, 1])
                        cylinder(h=4, d=1.8);
                }
    }
}

module wearable_back() {
    difference() {
        cylinder(h=2.5, d=outer_d - 1.2);
        // battery access / engraving
        translate([-8, -4, 1.8])
            cube([16, 8, 1]);
    }
}

// Preview
wearable_body();
translate([0, 0, -4])
    color("gray", 0.8) wearable_back();

// Export one part at a time:
// wearable_body();
// wearable_back();