Add one .step file for every part you modeled (enclosure, mounts, etc.)
