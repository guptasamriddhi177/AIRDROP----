# Suggested Pinouts (Prototype Reference)

> These are recommended starting pin assignments. Final PCB layout may adjust them for routing convenience.

## Pod — ESP32 Node A (Main)

| Function              | GPIO   | Notes                          |
|-----------------------|--------|--------------------------------|
| I2C SDA (BME680/MPU)  | 21     | Default ESP32 I2C              |
| I2C SCL               | 22     |                                |
| HC-SR04 #1 TRIG       | 5      |                                |
| HC-SR04 #1 ECHO       | 18     | Level shift if needed          |
| HC-SR04 #2 TRIG       | 19     |                                |
| HC-SR04 #2 ECHO       | 23     |                                |
| Status LED            | 2      | On-board or external           |
| ESP-NOW               | —      | Uses Wi-Fi radio               |
| BLE                   | —      | Uses Bluetooth radio           |
| Wi-Fi                 | —      | Cloud uplink                   |

## Pod — ESP32 Node B (Sensor Node)

| Function              | GPIO   | Notes                          |
|-----------------------|--------|--------------------------------|
| I2C SDA               | 21     | Shared bus or dedicated        |
| I2C SCL               | 22     |                                |
| Extra sensors / status| Free   |                                |
| ESP-NOW               | —      | Peer with Node A               |

## Wearable — ESP32-C3

| Function              | GPIO   | Notes                          |
|-----------------------|--------|--------------------------------|
| OLED SDA              | 8      | Common C3 default              |
| OLED SCL              | 9      |                                |
| Vibration Motor (via MOSFET) | 4 | PWM capable pin           |
| Buzzer                | 5      |                                |
| SOS Button            | 3      | INPUT_PULLUP                   |
| Battery ADC (optional)| 0 / 1  | Voltage monitoring             |
| Status LED            | 2 or built-in |                        |

**Important:** Always verify voltage levels (3.3 V logic). HC-SR04 ECHO is 5 V — use a level shifter or voltage divider when connecting to ESP32.