# AirDrop System Architecture

## High-Level Block Diagram

```
┌──────────────────────────────────────────────────────────────────┐
│                        AIRDROP POD                               │
│  ┌─────────────┐     ESP-NOW      ┌─────────────────────────┐   │
│  │  ESP32      │◄────────────────►│  ESP32 Node A           │   │
│  │  Node B     │                  │  (Main Controller)      │   │
│  │             │                  │  • Risk Engine          │   │
│  │ Sensors:    │                  │  • BLE Server           │   │
│  │ • BME680    │                  │  • Wi-Fi / Firebase     │   │
│  │ • MPU6050   │                  │  • Data Aggregation     │   │
│  │ • HC-SR04×2 │                  └───────────┬─────────────┘   │
│  └─────────────┘                              │                 │
└───────────────────────────────────────────────┼─────────────────┘
                                                │
                     ┌──────────────────────────┼──────────────────────────┐
                     │ BLE                      │ Wi-Fi                    │
                     ▼                          ▼                          │
          ┌─────────────────────┐    ┌─────────────────────┐              │
          │  AIRDROP WEARABLE   │    │     FIREBASE        │              │
          │  • ESP32-C3         │    │  Realtime Database  │              │
          │  • SSD1306 OLED     │    │  • Live data        │              │
          │  • Vibration Motor  │    │  • History          │              │
          │  • Buzzer           │    │  • Alerts           │              │
          │  • SOS Button       │    └──────────┬──────────┘              │
          │  • Battery          │               │                         │
          └─────────────────────┘               ▼                         │
                                     ┌─────────────────────┐              │
                                     │  AIRDROP WEB APP    │              │
                                     │  foresight-alert-   │              │
                                     │  sphere.lovable.app │              │
                                     │  • Dashboard        │              │
                                     │  • Risk history     │              │
                                     │  • Emergency UI     │              │
                                     └─────────────────────┘              │
```

## Data Flow Summary

1. **Sensing** → Node B (and shared sensors) collect raw readings  
2. **ESP-NOW** → Node B sends packet to Node A  
3. **Local Processing** → Node A validates, fuses, scores risk  
4. **BLE** → Node A notifies connected Wearable  
5. **Wi-Fi** → Node A pushes JSON record to Firebase  
6. **App** → Web client listens to Firebase and updates UI  

## Communication Technologies

| Link              | Protocol   | Direction        | Purpose                          |
|-------------------|------------|------------------|----------------------------------|
| Node B ↔ Node A   | ESP-NOW    | Bidirectional    | Sensor data exchange             |
| Pod ↔ Wearable    | BLE        | Pod → Wearable   | Live readings + alerts           |
| Pod ↔ Cloud       | Wi-Fi      | Pod → Firebase   | Persistence + multi-client sync  |
| Cloud ↔ App       | HTTPS/WS   | Bidirectional    | Dashboard & history              |