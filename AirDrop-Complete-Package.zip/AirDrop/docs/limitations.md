# Honest Engineering Limitations

For a credible engineering project these distinctions matter:

- **BME680 gas resistance** does not identify every toxic gas. It provides a relative gas resistance value that can indicate change, not absolute identification of specific toxins.
- **MPU6050** measures acceleration and angular rate. It does not independently detect earthquakes.
- **HC-SR04** is an ultrasonic distance sensor. It does not measure airflow or gas concentration.
- The current sensor combination does **not** directly detect wildfires.
- A reliable 1–24 hour environmental forecast requires appropriate historical data and a validated forecasting model.
- GPS / precise location tracking requires a location source (connected phone or dedicated GPS hardware).
- SOS delivery is **not** guaranteed to reach emergency services without a working communication route (BLE → phone → network, or direct network path).

These points are listed deliberately so the project stays scientifically honest while still showing a clear path for future development.