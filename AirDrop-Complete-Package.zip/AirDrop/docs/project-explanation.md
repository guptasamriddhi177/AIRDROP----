# AirDrop — Complete Project Explanation

## ENVIRONMENTAL INTELLIGENCE • PERSONAL SAFETY • CONNECTED TECHNOLOGY

AirDrop is a connected environmental safety ecosystem consisting of two main physical devices — an **AirDrop Pod** and an **AirDrop Wearable** — supported by a mobile application and a cloud-based data system.

**The central idea is simple:**

> The Pod monitors the environment.  
> The Wearable keeps the person informed.  
> The App connects everything.

AirDrop is designed to help people understand their surroundings, recognize potentially unsafe environmental changes, and receive timely warnings.

---

## 1. The Three Major Parts of AirDrop

### 01. AirDrop Pod
The main environmental monitoring unit. It collects sensor readings, processes them and calculates a preliminary environmental risk level.

### 02. AirDrop Wearable
A smartwatch-style companion that receives information from the Pod, displays warnings, vibrates during alerts and provides an SOS interface.

### 03. AirDrop Application
A central dashboard for monitoring readings, viewing risk history, checking location-based information and managing emergency contacts.

Live app: https://foresight-alert-sphere.lovable.app/

---

## 2. AirDrop Pod — Hardware & Sensing

### Hardware and components

| Component     | Purpose                                                      |
|---------------|--------------------------------------------------------------|
| ESP32 Node A  | Main controller and coordinator                              |
| ESP32 Node B  | Secondary sensing controller                                 |
| BME680        | Temperature, humidity, pressure and gas-resistance readings  |
| MPU6050       | Acceleration, movement, vibration and orientation            |
| 2 × HC-SR04   | Distance / proximity measurements                            |
| ESP-NOW       | Communication between the two ESP32 nodes                    |
| Wi-Fi         | Cloud communication with Firebase                            |

### How the sensors work

**A. BME680 — Environmental sensing**  
Measures temperature, relative humidity, atmospheric pressure and gas resistance. Gas resistance can help indicate changes in air composition but is **not** a direct measurement of every individual toxic gas.

**B. MPU6050 — Movement and vibration**  
Measures acceleration, angular movement, orientation changes and vibration patterns. Useful for detecting unusual physical disturbance around the device.

**C. HC-SR04 — Distance sensing**  
Uses ultrasonic sound waves to estimate distance to nearby objects. Provides proximity information only.

### How the Pod processes information
1. Sensors collect readings  
2. Each ESP32 reads its assigned sensors  
3. Node B transmits readings to Node A using ESP-NOW  
4. Node A combines the readings  
5. Firmware checks for invalid readings and unusual changes  
6. A preliminary risk score and status are calculated  
7. Information is sent to the wearable (BLE) and Firebase (Wi-Fi)

---

## 3. AirDrop Wearable — Personal Safety Companion

### Proposed wearable hardware

| Component                      | Purpose                       |
|--------------------------------|-------------------------------|
| ESP32-C3                       | Wearable controller           |
| 0.96-inch SSD1306 OLED         | Displays readings and alerts  |
| Vibration motor                | Silent physical warnings      |
| Transistor / MOSFET driver     | Controls vibration motor      |
| Buzzer                         | Audible alerts                |
| SOS button                     | Emergency request             |
| Protected Li-ion / LiPo battery| Portable power supply         |

### How the wearable works
1. Connects to the AirDrop Pod through Bluetooth Low Energy (BLE)  
2. Receives environmental readings, risk status and connection information  
3. OLED shows current risk, key readings, connection & battery status  
4. On warning: visual alert + vibration (+ optional buzzer)  
5. SOS button creates an emergency request (passed to phone / network when available)  
6. Continues local alerts over BLE even when internet is unavailable

---

## 4. Complete System Architecture

```
AIRDROP POD — SENSOR NETWORK
BME680 • MPU6050 • 2 × HC-SR04
ESP32 NODE B → ESP-NOW → NODE A
         │
LOCAL PROCESSING & RISK ENGINE
Validation • Sensor fusion • Trend analysis • Risk classification
         │
    ┌────┴────┐
   BLE       Wi-Fi
    │          │
Wearable    Firebase
OLED +      Data • Alerts • History
Vibration
+ SOS
    │
AIRDROP MOBILE APPLICATION
Dashboard • Maps • Risk history • Emergency contacts
```

---

## 5. The AirDrop Risk Assessment Engine

The intelligence layer takes multiple sensor readings and looks for unusual environmental patterns (sudden temperature change, significant gas-resistance shift, unusual vibration, multi-sensor correlation).

**Proposed classification (prototype only):**

| Status   | Score  |
|----------|--------|
| Safe     | 0–25   |
| Caution  | 26–50  |
| Warning  | 51–75  |
| Critical | 76–100 |

These bands are **not** scientifically validated safety thresholds. Real deployment requires calibration and extensive testing.

---

## 6. What the Application Does

| Feature          | Function                                      |
|------------------|-----------------------------------------------|
| Live dashboard   | Displays sensor readings                      |
| Risk indicator   | Shows current risk classification             |
| Location map     | Displays available location-tagged readings   |
| Historical data  | Tracks environmental changes over time        |
| Alerts           | Shows warnings and notifications              |
| Rescue mode      | Provides an emergency interface               |

Firebase Realtime Database is used as the communication and storage layer.

Example record structure:

```json
{
  "temperature": 30.5,
  "humidity": 62,
  "pressure": 1008,
  "gas_resistance": 12500,
  "vibration": 0.12,
  "distance": 45,
  "risk_score": 18,
  "risk_status": "Safe",
  "timestamp": "server_timestamp"
}
```

---

## 7. Use Cases

- Environmental monitoring in homes, schools and public spaces  
- Industrial / workplace condition awareness  
- School & college indoor environment monitoring  
- Disaster preparedness support  
- Personal safety via wearable alerts

---

## 8. What Makes AirDrop Different

| Traditional monitoring          | AirDrop ecosystem                          |
|--------------------------------|--------------------------------------------|
| Individual sensor readings     | Multiple sensor inputs + fusion            |
| Device-based monitoring only   | Pod + personal wearable                    |
| Requires checking a display    | Physical wrist alerts                      |
| Limited history                | Cloud-based data history                   |
| Basic threshold alerts         | Multi-sensor risk assessment (planned)     |
| Separate interfaces            | Connected hardware + app                   |

The strongest differentiator is the combination of environmental sensing with a personal wearable safety interface.

---

## 9. What AirDrop Cannot Claim Yet

- BME680 gas resistance does not identify every toxic gas  
- MPU6050 does not independently detect earthquakes  
- HC-SR04 does not measure airflow  
- Current sensor combination does not directly detect wildfires  
- Forecast features require validated models  
- GPS location requires additional hardware or phone  
- SOS is not guaranteed without a working communication path  

These are future engineering opportunities, not current claims.

---

## 10. Development Roadmap

1. Complete Pod electronics and PCB  
2. Integrate and calibrate sensors  
3. Establish communication between ESP32 nodes  
4. Develop local risk assessment  
5. Build the smartwatch wearable  
6. Integrate BLE and vibration alerts  
7. Connect Firebase  
8. Integrate the mobile dashboard  
9. Test SOS and offline functionality  
10. Validate the complete system  

---

## 11. Bigger Vision

AirDrop can grow into a connected environmental safety network where multiple Pods monitor different locations, wearables notify individuals, and a central application visualizes conditions across schools, industrial sites, communities and personal use cases.