# One-Minute Project Explanation

AirDrop is a connected environmental safety ecosystem that combines a multi-sensor monitoring device, a smartwatch-style wearable and a mobile application.

The **AirDrop Pod** uses ESP32 controllers and environmental + motion sensors to collect information about surrounding conditions. This information is processed locally to identify unusual patterns and calculate a preliminary risk score.

The **AirDrop Wearable** connects to the Pod through Bluetooth Low Energy, allowing users to receive real-time readings, vibration alerts and emergency SOS functionality directly on their wrist.

Meanwhile, Wi-Fi connects the Pod to Firebase, enabling cloud-based data storage, historical monitoring and communication with the AirDrop application.

Our ultimate vision is to create an accessible, intelligent environmental safety network that helps people become more aware of their surroundings and respond to potential environmental hazards before situations escalate.

**AirDrop: Detect. Alert. Stay Safe.**

Live demo app: https://foresight-alert-sphere.lovable.app/