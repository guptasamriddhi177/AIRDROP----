# AirDrop Wearable Firmware (ESP32-C3)

## Responsibilities
- Scan and connect to AirDrop Pod over BLE
- Receive live readings + risk status
- Drive 0.96" SSD1306 OLED
- Trigger vibration motor (and optional buzzer) on alerts
- Handle SOS button press and forward emergency request
- Show connection / battery status
- Continue local operation when cloud is offline

## Suggested Structure
```
wearable/
├── platformio.ini
├── src/
│   ├── main.cpp
│   ├── ble_client.h / .cpp
│   ├── display.h / .cpp
│   ├── haptics.h / .cpp
│   ├── sos.h / .cpp
│   └── config.h
└── README.md
```

## OLED Screens (suggested)
1. Home / Risk status (big status text + score)
2. Live readings (temp, humidity, gas, vibration)
3. Connection & battery
4. Alert / SOS confirmation screen

## Alert Behaviour
- On Warning or Critical packet:
  - Update OLED immediately
  - Pulse vibration motor (pattern can escalate with severity)
  - Optional short buzzer chirp
- SOS button:
  - Debounce
  - Send SOS flag over BLE to Pod
  - Pod can then push to Firebase / phone path
  - Show confirmation or “waiting for delivery” state on OLED

## Notes
Firmware is structured and ready for implementation.  
Untested status is acceptable for a pure design submission.