/**
 * AirDrop Wearable — ESP32-C3
 * BLE client, OLED, vibration, SOS
 */

#include <Arduino.h>
#include <Wire.h>
#include <BLEDevice.h>
#include <BLEClient.h>
// In real build: #include <Adafruit_SSD1306.h>  #include <Adafruit_GFX.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
// Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

#define VIB_PIN     4
#define BUZZER_PIN  5
#define SOS_PIN     3

#define BLE_SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define BLE_CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"

BLEClient* pClient = nullptr;
BLERemoteCharacteristic* pRemoteChar = nullptr;
bool connected = false;

String lastStatus = "----";
int lastScore = 0;

void vibrate(int pattern) {
  // Simple patterns: 1 = short, 2 = double, 3 = long alert
  for (int i = 0; i < pattern; i++) {
    digitalWrite(VIB_PIN, HIGH);
    delay(150);
    digitalWrite(VIB_PIN, LOW);
    delay(100);
  }
}

void updateDisplay(const char* status, int score) {
  // display.clearDisplay();
  // display.setTextSize(2);
  // display.setCursor(0, 0);
  // display.println(status);
  // display.setTextSize(1);
  // display.printf("Score: %d", score);
  // display.display();
  Serial.printf("OLED -> %s (%d)\n", status, score);
}

class MyClientCallback : public BLEClientCallbacks {
  void onConnect(BLEClient* c) { connected = true; }
  void onDisconnect(BLEClient* c) { connected = false; }
};

void notifyCallback(BLERemoteCharacteristic* pChar, uint8_t* pData, size_t length, bool isNotify) {
  char buf[64];
  size_t n = length < 63 ? length : 63;
  memcpy(buf, pData, n);
  buf[n] = 0;

  // Expected format: "Status|score|temp|hum"
  char status[16];
  int score = 0;
  sscanf(buf, "%15[^|]|%d", status, &score);

  lastStatus = status;
  lastScore = score;
  updateDisplay(status, score);

  if (strcmp(status, "Warning") == 0) vibrate(2);
  if (strcmp(status, "Critical") == 0) vibrate(3);
}

bool connectToPod() {
  BLEDevice::init("AirDrop-Wearable");
  pClient = BLEDevice::createClient();
  pClient->setClientCallbacks(new MyClientCallback());

  // In production: scan for "AirDrop-Pod" then connect by address
  // For skeleton we leave the scan/connect logic as clear TODO
  Serial.println("BLE client ready — implement scan + connect to AirDrop-Pod");
  return false;
}

void setup() {
  Serial.begin(115200);
  pinMode(VIB_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(SOS_PIN, INPUT_PULLUP);

  Wire.begin(8, 9); // ESP32-C3 common I2C pins
  // display.begin(SSD1306_SWITCHCAPVCC, 0x3C);

  updateDisplay("Boot", 0);
  connectToPod();
}

void loop() {
  // SOS handling
  if (digitalRead(SOS_PIN) == LOW) {
    delay(50); // debounce
    if (digitalRead(SOS_PIN) == LOW) {
      Serial.println("SOS PRESSED");
      vibrate(4);
      // TODO: write SOS flag to a characteristic or notify Pod
      updateDisplay("SOS!", 100);
      delay(2000);
    }
  }

  delay(20);
}