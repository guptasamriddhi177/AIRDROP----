# AirDrop Pod — Node A (Main Controller)

This is the primary ESP32 firmware for the AirDrop Pod.

## Responsibilities
- Receive sensor packets from Node B via ESP-NOW
- Read any sensors attached directly to Node A
- Validate readings and run the local risk engine
- Act as BLE server / notifier for the Wearable
- Push data to Firebase over Wi-Fi
- Maintain connection status and basic health

## Suggested Structure
```
pod_nodeA/
├── platformio.ini          (or Arduino .ino)
├── src/
│   ├── main.cpp
│   ├── sensors.h / .cpp
│   ├── risk_engine.h / .cpp
│   ├── espnow_handler.h / .cpp
│   ├── ble_server.h / .cpp
│   ├── firebase_client.h / .cpp
│   └── config.h
└── README.md
```

## Key Data Structure (example)
```cpp
struct SensorPacket {
  float temperature;
  float humidity;
  float pressure;
  float gasResistance;
  float accelX, accelY, accelZ;
  float vibrationMagnitude;
  float distance1;
  float distance2;
  uint32_t timestamp;
};

struct RiskResult {
  uint8_t score;          // 0-100
  const char* status;     // "Safe", "Caution", "Warning", "Critical"
};
```

## Risk Engine Outline
1. Reject clearly invalid readings (NaN, out-of-range)
2. Compute short-term deltas / trends
3. Weight contributions (gas change, vibration spike, temp jump, etc.)
4. Map to 0–100 score and status string
5. Trigger BLE notification when status changes to Warning/Critical

## Notes for Design Submission
Firmware is provided as a complete architectural skeleton.  
It is acceptable for a design submission that the code is still untested on final hardware.