/**
 * AirDrop Pod — Node A (Main Controller)
 * Design submission firmware skeleton
 * 
 * Responsibilities:
 *  - Receive SensorPacket via ESP-NOW from Node B
 *  - Local risk engine
 *  - BLE notifications to Wearable
 *  - Wi-Fi / Firebase uplink
 */

#include <Arduino.h>
#include <WiFi.h>
#include <esp_now.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

// ============ CONFIG ============
const char* WIFI_SSID     = "YOUR_SSID";
const char* WIFI_PASSWORD = "YOUR_PASSWORD";
// Firebase URL / auth would go here (use Firebase ESP Client library in real build)

#define BLE_SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define BLE_CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"

// ============ DATA STRUCTURES ============
typedef struct __attribute__((packed)) {
  float temperature;
  float humidity;
  float pressure;
  float gasResistance;
  float accelX, accelY, accelZ;
  float vibrationMagnitude;
  float distance1;
  float distance2;
  uint32_t timestamp;
} SensorPacket;

typedef struct {
  uint8_t score;          // 0-100
  char status[16];        // "Safe","Caution","Warning","Critical"
} RiskResult;

SensorPacket latestPacket;
RiskResult   latestRisk;
bool         newData = false;

// ============ RISK ENGINE ============
RiskResult calculateRisk(const SensorPacket& p) {
  RiskResult r;
  r.score = 0;

  // Example rule-based scoring (prototype — must be calibrated)
  // Temperature anomaly
  if (p.temperature > 40.0f || p.temperature < 5.0f) r.score += 25;
  else if (p.temperature > 35.0f || p.temperature < 10.0f) r.score += 10;

  // Humidity extremes
  if (p.humidity > 90.0f || p.humidity < 15.0f) r.score += 15;

  // Gas resistance drop (relative — not absolute toxic detection)
  // Lower resistance can indicate more VOCs; threshold is device-specific
  if (p.gasResistance > 0 && p.gasResistance < 5000.0f) r.score += 20;
  else if (p.gasResistance > 0 && p.gasResistance < 10000.0f) r.score += 8;

  // Vibration spike
  if (p.vibrationMagnitude > 2.5f) r.score += 25;
  else if (p.vibrationMagnitude > 1.2f) r.score += 10;

  // Proximity sudden change could be added with history

  if (r.score > 100) r.score = 100;

  if      (r.score <= 25) strcpy(r.status, "Safe");
  else if (r.score <= 50) strcpy(r.status, "Caution");
  else if (r.score <= 75) strcpy(r.status, "Warning");
  else                    strcpy(r.status, "Critical");

  return r;
}

// ============ ESP-NOW CALLBACK ============
void onDataRecv(const uint8_t *mac, const uint8_t *incomingData, int len) {
  if (len == sizeof(SensorPacket)) {
    memcpy(&latestPacket, incomingData, sizeof(SensorPacket));
    latestRisk = calculateRisk(latestPacket);
    newData = true;
  }
}

// ============ BLE ============
BLECharacteristic *pCharacteristic;
bool deviceConnected = false;

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer* pServer) { deviceConnected = true; }
  void onDisconnect(BLEServer* pServer) { deviceConnected = false; }
};

void setupBLE() {
  BLEDevice::init("AirDrop-Pod");
  BLEServer *pServer = BLEDevice::createServer();
  pServer->setCallbacks(new ServerCallbacks());
  BLEService *pService = pServer->createService(BLE_SERVICE_UUID);
  pCharacteristic = pService->createCharacteristic(
    BLE_CHARACTERISTIC_UUID,
    BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY
  );
  pCharacteristic->addDescriptor(new BLE2902());
  pService->start();
  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(BLE_SERVICE_UUID);
  pAdvertising->start();
}

void notifyWearable() {
  if (!deviceConnected) return;
  // Simple status string for prototype
  char buf[64];
  snprintf(buf, sizeof(buf), "%s|%d|%.1f|%.1f",
           latestRisk.status, latestRisk.score,
           latestPacket.temperature, latestPacket.humidity);
  pCharacteristic->setValue(buf);
  pCharacteristic->notify();
}

// ============ SETUP / LOOP ============
void setup() {
  Serial.begin(115200);
  Serial.println("AirDrop Pod Node A starting...");

  // ESP-NOW
  WiFi.mode(WIFI_STA);
  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW init failed");
    return;
  }
  esp_now_register_recv_cb(onDataRecv);

  setupBLE();

  // WiFi for Firebase would be started here
  // WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
}

void loop() {
  if (newData) {
    newData = false;
    Serial.printf("Risk: %s (%d)  T=%.1f H=%.1f Gas=%.0f Vib=%.2f\n",
                  latestRisk.status, latestRisk.score,
                  latestPacket.temperature, latestPacket.humidity,
                  latestPacket.gasResistance, latestPacket.vibrationMagnitude);

    notifyWearable();

    // TODO: push JSON to Firebase when WiFi is connected
  }
  delay(50);
}