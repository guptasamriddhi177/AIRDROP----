/**
 * AirDrop Pod — Node B (Sensor Node)
 * Samples sensors and forwards SensorPacket to Node A via ESP-NOW
 */

#include <Arduino.h>
#include <Wire.h>
#include <WiFi.h>
#include <esp_now.h>
// In real build: #include <Adafruit_BME680.h>  #include <Adafruit_MPU6050.h>

typedef struct __attribute__((packed)) {
  float temperature;
  float humidity;
  float pressure;
  float gasResistance;
  float accelX, accelY, accelZ;
  float vibrationMagnitude;
  float distance1;
  float distance2;
  uint32_t timestamp;
} SensorPacket;

// Replace with real MAC of Node A
uint8_t nodeAAddress[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

esp_now_peer_info_t peerInfo;

// HC-SR04 pins (example)
#define TRIG1 5
#define ECHO1 18
#define TRIG2 19
#define ECHO2 23

float readDistance(int trig, int echo) {
  digitalWrite(trig, LOW);
  delayMicroseconds(2);
  digitalWrite(trig, HIGH);
  delayMicroseconds(10);
  digitalWrite(trig, LOW);
  long duration = pulseIn(echo, HIGH, 30000);
  if (duration == 0) return -1.0f;
  return duration * 0.0343f / 2.0f;
}

void setup() {
  Serial.begin(115200);
  pinMode(TRIG1, OUTPUT);
  pinMode(ECHO1, INPUT);
  pinMode(TRIG2, OUTPUT);
  pinMode(ECHO2, INPUT);

  Wire.begin(); // SDA=21, SCL=22 on classic ESP32

  // TODO: bme.begin() / mpu.begin()

  WiFi.mode(WIFI_STA);
  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW init failed");
    return;
  }

  memcpy(peerInfo.peer_addr, nodeAAddress, 6);
  peerInfo.channel = 0;
  peerInfo.encrypt = false;
  if (esp_now_add_peer(&peerInfo) != ESP_OK) {
    Serial.println("Failed to add peer");
  }
}

void loop() {
  SensorPacket packet = {};

  // TODO: real sensor reads
  // packet.temperature = bme.readTemperature();
  // packet.humidity    = bme.readHumidity();
  // ...
  // For design submission the structure and flow are complete

  packet.distance1 = readDistance(TRIG1, ECHO1);
  packet.distance2 = readDistance(TRIG2, ECHO2);
  packet.timestamp = millis();

  // Placeholder demo values so structure is testable
  packet.temperature = 25.0f;
  packet.humidity = 55.0f;
  packet.pressure = 1013.0f;
  packet.gasResistance = 15000.0f;
  packet.vibrationMagnitude = 0.1f;

  esp_err_t result = esp_now_send(nodeAAddress, (uint8_t*)&packet, sizeof(packet));
  if (result == ESP_OK) {
    Serial.println("Packet sent");
  }

  delay(1000); // 1 Hz sample rate for prototype
}