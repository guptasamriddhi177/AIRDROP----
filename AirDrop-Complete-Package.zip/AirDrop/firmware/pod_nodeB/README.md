# AirDrop Pod — Node B (Sensor Node)

Secondary ESP32 that focuses on continuous sensor sampling and forwards data to Node A.

## Responsibilities
- Read BME680, MPU6050 and HC-SR04 sensors (or subset)
- Package readings into a compact ESP-NOW packet
- Transmit to Node A at a defined interval (e.g. 1–2 Hz)
- Optional local status LED / error indication

## Suggested Structure
```
pod_nodeB/
├── platformio.ini
├── src/
│   ├── main.cpp
│   ├── sensors.h / .cpp
│   ├── espnow_tx.h / .cpp
│   └── config.h
└── README.md
```

## Packet Format (must match Node A)
Use the same `SensorPacket` structure defined on Node A so that deserialization is reliable.