# AirDrop Wearable — KiCad Project

## Required Files (Checklist Compliant)

| File | Purpose |
|------|---------|
| `AirDrop_Wearable.kicad_pro` | Project file |
| `AirDrop_Wearable.kicad_sch` | Schematic |
| `AirDrop_Wearable.kicad_pcb` | PCB layout |
| `AirDrop_Wearable.kicad_prl` | Local project settings |
| `gerbers.zip` | Manufacturing outputs |

## Design Intent
- Compact form factor suitable for wrist-worn enclosure
- ESP32-C3 module or SuperMini footprint
- I2C OLED (SSD1306)
- MOSFET/transistor footprint for vibration motor
- SOS button with good mechanical placement
- Battery connector + optional charging circuit (TP4056 area)
- Minimal height for comfortable wearable design

## Status
Structure is ready. Drop your completed KiCad files here.