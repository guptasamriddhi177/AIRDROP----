Export Gerbers + drill from KiCad and zip them as gerbers.zip in this folder
