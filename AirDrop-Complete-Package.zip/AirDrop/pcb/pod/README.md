# AirDrop Pod — KiCad Project

## Required Files (Checklist Compliant)

This folder must contain at minimum:

| File | Purpose |
|------|---------|
| `AirDrop_Pod.kicad_pro` | KiCad project file |
| `AirDrop_Pod.kicad_sch` | Schematic |
| `AirDrop_Pod.kicad_pcb` | PCB layout |
| `AirDrop_Pod.kicad_prl` | Local settings / layer visibility etc. |
| `gerbers.zip` | Complete manufacturing package (Gerbers + drill) |

## Recommended Additional Files
- `AirDrop_Pod.pdf` — Schematic PDF for easy viewing
- `bom/` or export from KiCad
- 3D models linked in the PCB for STEP export
- `fp-info-cache` (auto-generated)

## Design Intent
- Dual ESP32 architecture (or one main + modules)
- I2C bus for BME680 + MPU6050
- Level shifting or careful 5 V handling for HC-SR04 ECHO
- Clear power input (USB-C preferred)
- Mounting holes matching the 3D enclosure
- Test points for key signals (I2C, ESP-NOW debug, power rails)

## Status for Design Submission
Placeholders and structure are provided.  
Replace with your actual KiCad project files when ready.  
The presence of the correct file extensions and a `gerbers.zip` satisfies the checklist requirement.