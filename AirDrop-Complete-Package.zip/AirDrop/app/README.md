# AirDrop Application

**Live URL:** https://foresight-alert-sphere.lovable.app/

## Features Implemented / Planned
- Live sensor dashboard
- Risk status indicator
- Historical data views
- Emergency / rescue mode interface
- Firebase Realtime Database backend

## How it connects
The Pod pushes JSON records to Firebase.  
The web application listens to the same database paths and updates the UI in real time.

## Screenshots
Add screenshots of the live dashboard, risk history and any map views into the main `images/` folder and reference them from the root README.